<?php
$con=mysqli_connect('localhost','root','','robot') or die("unable to connect");
if(isset($_POST['submit'])){
$move=$_POST['submit'];
$sql="INSERT INTO remote_control(move) VALUES('$move')";
$result=mysqli_query($con,$sql);
if($result){
echo $move;
}
}
?>